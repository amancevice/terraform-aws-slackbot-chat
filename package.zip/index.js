const slackend = require('slackend/aws');
module.exports = slackend();
